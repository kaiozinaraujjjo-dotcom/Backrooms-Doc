/*
Design aplicado neste arquivo: Brutalismo cibernético de arquivo militar analógico.
Os dados tratam cada nível como registro de dossiê confidencial recuperado, com campos completos e anomalias catalogadas.
Pergunta de controle: esta escolha reforça ou dilui a filosofia de arquivo militar corrompido?
*/

const GENERATED_ASSETS = {
  level0: "https://d2xsxph8kpxj0f.cloudfront.net/310519663609394345/EpuPt7SKxmfdVEA58xUry7/backrooms_level0_fluorescent_archive-bcXvaXVWC9YxR75CRgRMDW.webp",
  level1: "https://d2xsxph8kpxj0f.cloudfront.net/310519663609394345/EpuPt7SKxmfdVEA58xUry7/backrooms_level1_concrete_maintenance-jLvL84H8hqVptriCkPnwqk.webp",
  level2: "https://d2xsxph8kpxj0f.cloudfront.net/310519663609394345/EpuPt7SKxmfdVEA58xUry7/backrooms_level2_pipe_tunnel_heat-aAceP6CvPthqQ3WcGbHkW8.webp",
  corrupt: "https://d2xsxph8kpxj0f.cloudfront.net/310519663609394345/EpuPt7SKxmfdVEA58xUry7/backrooms_signal_corruption_404-cHoJaXPPAfViZb3ENYxzPS.webp"
};

const levels = [];

levels.push({
  id: 0,
  name: "Level 0 — The Lobby",
  imageUrl: GENERATED_ASSETS.level0,
  entities: ["Nenhuma entidade confirmada", "Sussurros miméticos sem corpo", "Sombras periféricas não catalogadas"],
  entrances: "Noclip acidental por paredes úmidas, corredores de escritórios vazios ou portas de manutenção que não constavam na planta original.",
  exits: "Noclip raro através de paredes mais escuras; corredores que mergulham para o concreto de Level 1; escadas que surgem apenas depois de longos ciclos de caminhada.",
  size: "Aproximadamente 600 milhões de milhas quadradas de salas amarelas não lineares; medições retornam valores contraditórios.",
  survivalClass: { level: "Classe 1", description: "Seguro em termos físicos imediatos, instável em orientação, com drenagem mental progressiva e isolamento extremo." },
  credits: "Compilado por M.E.G. Archivist Node BR-07; referências cruzadas com relatos sobreviventes e folclore clássico das Backrooms.",
  sanityDrain: "3.8% por hora em silêncio; até 9% quando o zumbido fluorescente sincroniza com batimentos cardíacos.",
  availableLoot: ["Água de amêndoas em garrafas sem rótulo", "Fita isolante ressecada", "Clipes enferrujados", "Pedaços de carpete com cheiro de ozônio"],
  outposts: ["Posto Limiar-00, temporário e raramente reencontrado", "Marcações de giz do Grupo dos Perdidos, validade desconhecida"],
  avgTemperature: "21°C, apesar de sensação térmica úmida e febril.",
  lightingLevel: "Fluorescente constante, amarelado, sem fonte elétrica acessível; piscadas isoladas indicam mudança geométrica.",
  geometry: "Salas monoamarelas com ângulos quase retos; corredores reconfiguram relações espaciais quando não observados diretamente.",
  ambientSounds: ["Zumbido de lâmpadas em 60 Hz", "Carpete rangendo quando ninguém se move", "Gotejamento dentro das paredes sem tubulação"],
  survivorLog: "Dia 2, talvez. Desenhei setas na parede, mas elas apontam para mim quando volto. A luz nunca apaga; ela apenas espera eu piscar. Encontrei meu próprio nome escrito no carpete, com a grafia que minha mãe usava em bilhetes antigos.",
  toxicity: "Baixa toxicidade química; alta contaminação psicológica por monotonia visual e privação social.",
  wifiSignal: "Sinal intermitente chamado 'MISSING_PERSONNEL_GUEST'; conexão abre páginas que listam pessoas ainda vivas como desaparecidas.",
  discoveryDate: "12/05/1989",
  casualtyCount: "2.413 presumidos, 117 confirmados por gravações recuperadas.",
  timeDistortion: "Relógios digitais atrasam 11 minutos por hora subjetiva; gravações retornam com trechos que o operador ainda não viveu.",
  physicalAnomalies: ["Carpete úmido sem fonte de água", "Paredes que abafam gritos", "Portas desenhadas que se tornam reais durante apagões"],
  floraFauna: "Mofo amarelo pálido em cantos fechados; nenhum animal confirmado, embora pegadas pequenas apareçam ao redor de pessoas dormindo.",
  levelCycles: "Sem dia ou noite; ciclos de reorganização ocorrem após períodos de silêncio absoluto.",
  humidity: "73% média, com picos localizados que encharcam equipamentos em minutos.",
  materials: ["Papel de parede envelhecido", "Carpete industrial úmido", "Gesso oco", "Luminárias fluorescentes seladas"],
  themeColors: { bg: "#090B04", text: "#D7F6B0", accent: "#D4B43D" },
  easterEgg: true
});

levels.push({
  id: 1,
  name: "Level 1 — Habitable Zone",
  imageUrl: GENERATED_ASSETS.level1,
  entities: ["Hounds distantes", "Facelings passivos em corredores de carga", "Agentes humanos sem identificação"],
  entrances: "Noclip a partir de paredes escuras do Level 0, poços de elevador impossíveis e portas de serviço com cheiro de concreto molhado.",
  exits: "Escadas metálicas para níveis industriais; portas numeradas para hubs; áreas inundadas que descarregam em subníveis não autorizados.",
  size: "Complexo de manutenção potencialmente infinito, organizado em blocos de estacionamento, docas e salas técnicas.",
  survivalClass: { level: "Classe 1", description: "Habitável por curtos períodos, com recursos recuperáveis, zonas de abrigo e risco moderado de entidades." },
  credits: "Registro consolidado por células M.E.G., B.N.T.G. e testemunhos anônimos de comboios perdidos.",
  sanityDrain: "2.1% por hora em grupo; 6.4% por hora quando as luzes entram em modo de emergência.",
  availableLoot: ["Caixas de suprimentos reaparecendo", "Lanternas semi-carregadas", "Rações militares vencidas", "Ferramentas de manutenção", "Água de amêndoas"],
  outposts: ["Base Alpha, acesso controlado", "Mercado Cinza da doca leste", "Abrigo das Colunas 14-18"],
  avgTemperature: "16°C, com corredores frios próximos a portas pretas.",
  lightingLevel: "Baixo a moderado; falhas de energia produzem janelas de atividade hostil.",
  geometry: "Garagens e corredores de concreto em malha semi-estável; pilares repetem números que não batem com mapas.",
  ambientSounds: ["Gotejamento em poças", "Vibração de transformadores", "Rodas de carrinhos de carga em corredores vazios", "Rugidos distantes"],
  survivorLog: "A caixa de suprimentos apareceu de novo, no mesmo lugar, mas desta vez continha uma foto minha dormindo. O concreto atrás da Base Alpha começou a respirar às 03:17. Ninguém quis anotar no quadro. Eles dizem que mapas assustam os novatos.",
  toxicity: "Baixa; bolsões de mofo e vapores de combustível exigem máscara em docas específicas.",
  wifiSignal: "Rede 'ALPHA_INTERNAL' instável; mensagens chegam com remetente do próprio usuário, datadas do dia seguinte.",
  discoveryDate: "03/09/1990",
  casualtyCount: "891 confirmados, maioria durante apagões e deslocamentos solitários.",
  timeDistortion: "Relativamente estável; apagões podem avançar relógios em múltiplos de 17 minutos.",
  physicalAnomalies: ["Caixas que reaparecem após inventário", "Pilares que trocam de posição", "Sombras que permanecem depois da saída do corpo"],
  floraFauna: "Mofo cinza e liquens translúcidos em paredes úmidas; insetos sem olhos próximos a luminárias quebradas.",
  levelCycles: "Ciclo de energia de 9 a 27 horas; cada queda altera rotas secundárias.",
  humidity: "64% média; 91% nas áreas de drenagem.",
  materials: ["Concreto armado", "Aço oxidado", "Tinta industrial descascada", "Tubulação exposta", "Plástico de caixas logísticas"],
  themeColors: { bg: "#070908", text: "#DDE6C9", accent: "#A58B45" },
  easterEgg: false
});

levels.push({
  id: 2,
  name: "Level 2 — Pipe Dreams",
  imageUrl: GENERATED_ASSETS.level2,
  entities: ["Smilers em trechos sem luz", "Wretches isolados", "Crawlers térmicos não confirmados", "Hounds atraídos por vapor"],
  entrances: "Corredores de manutenção do Level 1, portas com calor excessivo, dutos grandes demais para a arquitetura declarada.",
  exits: "Escotilhas enferrujadas para níveis industriais; dutos de ar que comprimem o viajante para subníveis; portas frias que retornam ao Level 1.",
  size: "Rede claustrofóbica de túneis aquecidos e salas de válvulas; largura média inferior a 2 metros.",
  survivalClass: { level: "Classe 2", description: "Perigoso por calor, confinamento, hostilidade auditiva e encontros em pontos cegos." },
  credits: "Arquivo montado a partir de gravadores queimados, mapas térmicos e depoimentos de operadores de manutenção desaparecidos.",
  sanityDrain: "7.2% por hora; 14% em túneis onde os canos sussurram nomes de familiares.",
  availableLoot: ["Chaves de válvula", "Máscaras térmicas rasgadas", "Cabos de cobre", "Água de amêndoas morna", "Baterias inchadas"],
  outposts: ["Ninho de Válvulas 2-B, ocupação intermitente", "Posto Termal do grupo Boilerwatch"],
  avgTemperature: "34°C, com bolsas acima de 51°C perto de tubos vermelhos.",
  lightingLevel: "Baixo; lâmpadas de gaiola e brilho laranja de calor. Áreas completamente escuras são evitadas.",
  geometry: "Túneis longos, repetitivos e estreitos; curvas de 90 graus levam a trechos que não caberiam no espaço anterior.",
  ambientSounds: ["Vapor sob pressão", "Batidas metálicas em sequência inteligente", "Respiração dentro dos canos", "Alarmes baixos demais para localizar"],
  survivorLog: "Não era vapor. O som vinha de dentro do cano e repetia meu pedido de socorro com a voz do Pedro, que morreu no Level 1. A válvula 9 girou sozinha quando escrevi isto. Se a parede suar sangue de novo, não sigam o rastro; ele termina em dentes.",
  toxicity: "Moderada a alta; vapores metálicos e ar quente causam náusea, confusão e queimaduras respiratórias.",
  wifiSignal: "Quase nulo; pacotes chegam como caracteres repetindo 'OPEN THE VALVE'.",
  discoveryDate: "21/01/1991",
  casualtyCount: "1.206 estimados; corpos raramente permanecem onde caem.",
  timeDistortion: "Relógios analógicos aceleram perto de válvulas vermelhas; o tempo subjetivo alonga em passagens estreitas.",
  physicalAnomalies: ["Tubos quentes sem fonte térmica", "Portas frias em paredes incandescentes", "Condensação com padrões de escrita", "Metais que sangram ferrugem fresca"],
  floraFauna: "Fungos alaranjados em juntas de tubos; larvas translúcidas que evaporam sob luz direta.",
  levelCycles: "Picos de pressão a cada 6 horas aproximadas; após cada pico, alguns corredores invertem direção.",
  humidity: "88% média, saturada por vapor oleoso.",
  materials: ["Ferro fundido", "Aço quente", "Concreto queimado", "Válvulas oxidadas", "Grades industriais"],
  themeColors: { bg: "#120604", text: "#FFE2B7", accent: "#D95B24" },
  easterEgg: true
});

(function createRecoveredLevelStubs() {
  const archetypes = [
    { title: "Maintenance Sprawl", entities: ["Hounds", "Facelings operários"], image: GENERATED_ASSETS.level1, bg: "#070A08", text: "#D8E7C6", accent: "#8EA15B", material: "concreto manchado" },
    { title: "Thermal Utility Corridor", entities: ["Smilers", "Wretches térmicos"], image: GENERATED_ASSETS.level2, bg: "#130704", text: "#FFE1C2", accent: "#C65125", material: "aço superaquecido" },
    { title: "Fluorescent Office Drift", entities: ["Sussurros miméticos", "Sombras periféricas"], image: GENERATED_ASSETS.level0, bg: "#0B0C05", text: "#E6F4B5", accent: "#BFA638", material: "papel de parede úmido" },
    { title: "Archive Atrium", entities: ["Facelings arquivistas", "Page Eaters"], image: "missing://classified/atrium", bg: "#080A0C", text: "#D5E8E8", accent: "#4DA6A6", material: "vidro fosco e aço" },
    { title: "Suburban Null Block", entities: ["Skin-Stealers", "Cães sem mandíbula"], image: "missing://classified/suburb", bg: "#0C090D", text: "#E8D6EF", accent: "#9C6AB5", material: "drywall oco" },
    { title: "Flooded Service Deck", entities: ["Drowned Facelings", "Hounds aquáticos"], image: "missing://classified/flood", bg: "#061014", text: "#CFEEF4", accent: "#2E94B8", material: "azulejo rachado" }
  ];

  const loot = ["água de amêndoas", "bateria industrial", "fita de marcação", "máscara de poeira", "lanterna de emergência", "mapa parcial", "rádio com chiado", "comprimidos sem bula"];
  const sounds = ["zumbido elétrico", "passos dois corredores atrás", "ventilação irregular", "gotejamento sincronizado", "batidas sob o piso", "rádio militar enterrado em estática"];
  const anomalies = ["portas que mudam de lado", "sombras com atraso", "paredes respirando", "bússolas girando", "sinais de saída apontando para becos", "temperatura invertida entre salas"];
  const flora = ["mofo pálido", "líquens translúcidos", "raízes sem origem", "poeira orgânica", "fungos de ferrugem", "nenhuma forma viva confirmada"];

  for (let id = 3; id <= 100; id += 1) {
    const a = archetypes[id % archetypes.length];
    const cycle = (id % 9) + 3;
    const hazard = id % 5;
    const casualtyBase = id * 17 + (hazard * 23);
    const img = id % 10 === 0 ? `missing://archive/level-${id}` : a.image;
    levels.push({
      id,
      name: `Level ${id} — ${a.title}`,
      imageUrl: img,
      entities: [a.entities[0], a.entities[1], id % 7 === 0 ? "Entidade não classificada vista apenas em reflexos" : "Ausência hostil de fauna confirmada"],
      entrances: `Acesso por noclip a partir de zonas com ${a.material}, principalmente quando o viajante repete a mesma rota por ${cycle} ciclos. Registros de entrada também citam portas marcadas com o número ${id} em níveis anteriores.`,
      exits: `Saídas instáveis para níveis adjacentes, escotilhas de manutenção e corredores que reduzem a pressão sonora. Equipes recomendam seguir cabos pretos por no máximo ${cycle + 2} minutos.`,
      size: `${(id * 13).toLocaleString('pt-BR')} km² mapeados, extensão real não confirmada; mapas dobram sobre si mesmos após revisão.`,
      survivalClass: {
        level: `Classe ${1 + (id % 5)}`,
        description: hazard < 2 ? "Sobrevivência possível com disciplina, luz e rota de retirada." : hazard < 4 ? "Risco elevado por geometrias hostis, recursos inconsistentes e encontros imprevisíveis." : "Altamente instável; entrada não autorizada tratada como perda operacional provável."
      },
      credits: `Registro recuperado pelo Arquivo M.E.G. BR-${String(id).padStart(3, '0')}; validação cruzada por três relatos incompletos e telemetria corrompida.`,
      sanityDrain: `${(2.4 + (id % 11) * 0.7).toFixed(1)}% por hora; dobra quando sinais auditivos usam nomes pessoais.`,
      availableLoot: [loot[id % loot.length], loot[(id + 2) % loot.length], loot[(id + 5) % loot.length]],
      outposts: [`Posto provisório ${id}-${String.fromCharCode(65 + (id % 26))}`, id % 4 === 0 ? "Sinal de abrigo abandonado, sem ocupantes" : "Nenhum outpost permanente confirmado"],
      avgTemperature: `${8 + (id % 38)}°C, com microclimas inconsistentes perto de transições geométricas.`,
      lightingLevel: id % 3 === 0 ? "Baixo e pulsante, dependente de painéis sem fiação visível." : id % 3 === 1 ? "Moderado, fluorescente e desconfortavelmente uniforme." : "Irregular; escuridão total em zonas de eco.",
      geometry: `Setores de ${a.material} organizados em sequência aparentemente lógica, quebrada por retornos impossíveis e corredores que removem portas já observadas.`,
      ambientSounds: [sounds[id % sounds.length], sounds[(id + 2) % sounds.length], sounds[(id + 4) % sounds.length]],
      survivorLog: `Registro ${id}.${cycle}: contei as passagens e perdi uma que estava atrás de mim. O rádio repetiu minha respiração com ${cycle} segundos de antecedência. Quando deixei uma marca no ${a.material}, ela reapareceu na minha pele com a tinta ainda fresca.`,
      toxicity: hazard === 0 ? "Baixa, mas partículas suspensas causam irritação ocular." : hazard === 1 ? "Moderada em bolsões fechados; máscara recomendada." : hazard === 2 ? "Alta em salas quentes e câmaras sem ventilação." : hazard === 3 ? "Variável, com surtos químicos sem aviso." : "Desconhecida; sintomas surgem antes da exposição mensurável.",
      wifiSignal: id % 6 === 0 ? "Sinal forte demais, sem internet, transmitindo nomes de desaparecidos." : id % 6 === 1 ? "Intermitente, SSID muda conforme o nível de medo do operador." : "Inexistente, exceto pacotes vazios recebidos às 03:17.",
      discoveryDate: `${String((id % 28) + 1).padStart(2, '0')}/${String((id % 12) + 1).padStart(2, '0')}/${1991 + (id % 30)}`,
      casualtyCount: `${casualtyBase} estimados; confirmação visual prejudicada por remoção anômala de corpos.`,
      timeDistortion: `Desvio médio de ${(id % 13) + 1} minutos por hora subjetiva; gravações podem anteceder eventos por um ciclo.`,
      physicalAnomalies: [anomalies[id % anomalies.length], anomalies[(id + 3) % anomalies.length], anomalies[(id + 5) % anomalies.length]],
      floraFauna: `${flora[id % flora.length]} detectado em zonas úmidas; fauna convencional ausente ou convertida em ruído de fundo.`,
      levelCycles: `Ciclo operacional de aproximadamente ${cycle} horas, marcado por mudança de luz, pressão e posição de saídas.`,
      humidity: `${35 + (id % 61)}% média, com leituras divergentes entre sensores a menos de um metro.`,
      materials: [a.material, id % 2 === 0 ? "metal oxidado" : "plástico institucional", id % 3 === 0 ? "vidro opaco" : "concreto poroso"],
      themeColors: { bg: a.bg, text: a.text, accent: a.accent },
      easterEgg: id % 17 === 0 || id === 66
    });
  }
})();

window.levels = levels;
window.GENERATED_ASSETS = GENERATED_ASSETS;
